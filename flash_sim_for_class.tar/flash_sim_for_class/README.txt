This hspice experiment plots I_DS vs. V_GS curves for 4 different flash FETs, each with a different threshold voltage (V_TH).

The 4 flash models are defined in the file flash_fets.pm. Note that each FET has many parameters, one of which is vth0. The parameter vth0 controls the V_TH of the FET. The V_TH is also affected by other things, like channel length, but the primary control of V_TH is the parameter vth0.

The values of the vth0 parameters for each flash FET are defined in the file flash_params.inc. Each flash FET is given a different V_TH. You can ignore the parameters mobility and tox.

The spice file test_flsah.sp simulates the 4 flash FETs, and measures the I_DS of each, as the V_GS is increased in a ramp. To run the spice file:
    hspice test_flash.sp

This will run the spice simulation, and generate some files including a test_flash.tr0 file which contains the measurements of the transient simulation.
Open the test_flash.tr0 file in waveview:
    wv test_flash.tr0    

Plot the waveforms I(Mflash0), I(Mflash1), I(Mflash2), and I(Mflash3) to see the I_DS vs. V_GS curves. The 4 curves should correspond to the V_TH values of the flash FETs. 


